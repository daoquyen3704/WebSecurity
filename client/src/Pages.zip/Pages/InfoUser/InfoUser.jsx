import { useState } from 'react';
import { Layout, Menu, Avatar, Typography, Card } from 'antd';
import {
  UserOutlined,
  FileTextOutlined,
  DollarCircleOutlined,
  LockOutlined,
} from '@ant-design/icons';

import Header from '../../Components/Header/Header';
import { useStore } from '../../hooks/useStore';

import PersonalInfo from './Components/PersonalInfo/PersonalInfo';
import ManagerPost from './Components/ManagerPost/ManagerPost';
import RechargeUser from './Components/RechargeUser/RechargeUser';
import ChangePassword from './Components/ChangePassword/ChangePassword';

import userNotFound from '../../assets/images/img_default.svg';
import './infouser.theme.scss'; // Theme navy + chữ trắng (đã đồng bộ với Admin)

const { Sider, Content } = Layout;
const { Title, Text } = Typography;

export default function InfoUser() {
  const { dataUser } = typeof useStore === 'function' ? useStore() : { dataUser: null };
  const [selectedMenu, setSelectedMenu] = useState('personal');

  const items = [
    { key: 'personal', icon: <UserOutlined />, label: 'Thông tin cá nhân' },
    { key: 'change-password', icon: <LockOutlined />, label: 'Đổi mật khẩu' },
    { key: 'posts', icon: <FileTextOutlined />, label: 'Quản lý bài viết' },
    { key: 'recharge', icon: <DollarCircleOutlined />, label: 'Nạp tiền' },
  ];

  const renderTitle = () => {
    switch (selectedMenu) {
      case 'personal': return 'Thông tin cá nhân';
      case 'change-password': return 'Đổi mật khẩu';
      case 'posts': return 'Quản lý bài viết';
      case 'recharge': return 'Nạp tiền';
      default: return '';
    }
  };

  return (
    <div className="infouser">
      <Header />

      <Layout style={{ minHeight: '70vh' }}>
        <Sider width={260}>
          <div className="cluster" style={{ padding: 16 }}>
            <Avatar size={64} icon={<UserOutlined />} src={dataUser?.avatar || userNotFound} />
            <div style={{ minWidth: 0 }}>
              <Title level={4} style={{ margin: 0 }}>
                {dataUser?.fullName || 'Người dùng'}
              </Title>
              <Text style={{ display: 'block' }}>
                {dataUser?.email || '—'}
              </Text>
            </div>
          </div>

          <Menu
            mode="inline"
            selectedKeys={[selectedMenu]}
            onClick={({ key }) => setSelectedMenu(key)}
            items={items}
            theme="dark" // icon trắng mặc định; nền/hover/selected đã override bằng SCSS
          />
        </Sider>

        <Layout>
          <Content style={{ padding: 24 }}>
            <Card
              className="section"
              title={
                <div className="cluster" style={{ justifyContent: 'space-between' }}>
                  <Title level={3} style={{ margin: 0 }}>{renderTitle()}</Title>
                </div>
              }
            >
              {selectedMenu === 'personal' && <PersonalInfo />}
              {selectedMenu === 'change-password' && <ChangePassword />}
              {selectedMenu === 'posts' && <ManagerPost />}
              {selectedMenu === 'recharge' && <RechargeUser />}
            </Card>
          </Content>
        </Layout>
      </Layout>
    </div>
  );
}
