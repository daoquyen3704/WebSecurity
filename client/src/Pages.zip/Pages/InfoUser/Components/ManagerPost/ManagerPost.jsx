import React, { useState } from 'react';
import { Table, Button, Tag, Space } from 'antd';
import classNames from 'classnames/bind';
import styles from './ManagerPost.module.scss';

const cx = classNames.bind(styles);

function ManagerPost() {
  const [data, setData] = useState([
    {
      key: '1',
      title: 'Căn hộ mini Hoàng Mai',
      price: '4.500.000 VND',
      type: 'Căn hộ mini',
      area: '25 m²',
      address: 'Đường Hoàng Mai, Hà Nội',
      status: 'Đã duyệt',
    },
    {
      key: '2',
      title: 'Phòng trọ Cầu Giấy',
      price: '3.200.000 VND',
      type: 'Phòng trọ',
      area: '20 m²',
      address: 'Trần Quốc Hoàn, Cầu Giấy',
      status: 'Chờ duyệt',
    },
  ]);

  const columns = [
    {
      title: 'Tiêu đề',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Giá (VND)',
      dataIndex: 'price',
      key: 'price',
    },
    {
      title: 'Loại hình',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Diện tích',
      dataIndex: 'area',
      key: 'area',
    },
    {
      title: 'Địa chỉ',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: 'Trạng thái',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'Đã duyệt' ? 'green' : 'orange'}>{status}</Tag>
      ),
    },
    {
      title: 'Hành động',
      key: 'action',
      render: () => (
        <Space size="middle">
          <Button type="link">Sửa</Button>
          <Button type="link" danger>
            Xóa
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div className={cx('wrapper')}>
      <div className={cx('stats')}>
        <Button type="primary" style={{ marginBottom: 16 }}>
          + Thêm bài viết mới
        </Button>
        <Table
          columns={columns}
          dataSource={data}
          pagination={{ pageSize: 5 }}
          scroll={{ x: 'max-content' }}
        />
      </div>
    </div>
  );
}

export default ManagerPost;
